---
name: bluemetrics-design
description: Use this skill to generate well-branded interfaces and assets for bluemetrics — an AI and data consultancy — either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference

- **Brand**: bluemetrics — AI / data consultancy, Brazil + US.
- **Aesthetic**: Apple's editorial restraint × BlueMetrics' deep-blue palette.
- **Primary color**: `#0C27E8` (bm-blue). Single accent. Used sparingly.
- **Type**: Outfit (display) + Wix Madefor Text (body). 17px body. Sentence case.
- **Wordmark**: always lowercase — "bluemetrics".
- **Tile rhythm**: white → 28px-radius gray/dark tile → white. Apple-style sectioning.
- **CTAs**: pill-shape (`border-radius: 980px`). Primary blue, secondary outlined, ghost on dark.
- **Imagery**: 3D liquid metaballs in deep-blue/purple/magenta. Cool-toned, dark, abstract. Provided in `assets/bg-*.png/jpg`.
- **Icons**: Phosphor Icons (Regular weight, 1.5px stroke). No emoji.
- **Voice**: confident, direct, quantified. Two-sentence rhythm. Brazilian Portuguese is primary.

## Files to read first

1. `README.md` — full system rationale, content + visual foundations, iconography.
2. `colors_and_type.css` — all design tokens. Import this into any HTML you produce.
3. `ui_kits/website/` — concrete recreation showing tokens in use.
4. `preview/*.html` — single-concept specimen cards.
