# Website UI kit

Interactive recreation of the BlueMetrics public site (2026 redesign), built in the Apple-meets-BlueMetrics aesthetic established by this design system.

## Files

- `index.html` — the demo home page that wires the components together.
- `styles.css` — all kit-level styles (consumes tokens from `colors_and_type.css`).
- `components.jsx` — every section as a small, reusable React component.

## Components

| Component | What it is |
|---|---|
| `<NavBar />` | Sticky translucent top nav, light variant. |
| `<Hero />` | Full-bleed liquid-blue hero with eyebrow + title + sub + dual CTAs. |
| `<Solutions />` | 3-up card grid in light/dark/brand-blue tones. |
| `<Stats />` | 4-up numeric stats row (huge bm-blue numerals). |
| `<ShowcaseStage />` | Full-bleed image stage with case-study story. |
| `<IndustriesGrid />` | 2x2 industries cards on off-white section. |
| `<CTASection />` | Closing dark/blue stage with primary CTA. |
| `<Footer />` | 5-column Apple-style sitemap footer. |

## Visual rules followed

- **One blue.** All emphasis comes from `--bm-blue` (`#0c27e8`). Support colors are reserved for status/data viz.
- **Tile rhythm.** Sections alternate white → tile/stage → off-white. Apple's hallmark.
- **Pill CTAs.** All buttons use `--radius-pill` (980px).
- **Outfit titles, Wix Madefor body.** Both per the BlueMetrics brandbook.
- **Hero imagery from brandbook.** Liquid blue backgrounds (`bg-liquid-*`) for hero/CTA stages.

## Caveats

- Logos in the strip are placeholder text marks — the site would source real client logos.
- Hover states are simple background shifts; no micro-interactions yet.
- Mobile breakpoints not yet implemented; the kit targets 1248px desktop.
