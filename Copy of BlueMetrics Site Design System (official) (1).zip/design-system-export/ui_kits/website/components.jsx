/* global React */
const { useState } = React;

function NavBar() {
  const links = ['Soluções', 'Indústrias', 'Casos', 'Insights', 'Sobre'];
  return (
    <nav className="bm-nav">
      <div className="bm-nav__inner">
        <img className="bm-nav__logo" src="../../assets/logo-blue-horizontal.png" alt="bluemetrics" />
        <div className="bm-nav__links">
          {links.map(l => <a key={l} href="#">{l}</a>)}
        </div>
        <div className="bm-nav__icons">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M20 12a8 8 0 1 1-16 0 8 8 0 0 1 16 0z"/><path d="M12 8v4l3 2"/></svg>
        </div>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <section style={{ padding: '12px 24px 0' }}>
      <div className="bm-container">
        <div className="bm-hero bm-hero--liquid">
          <div className="bm-hero__eyebrow">Inteligência artificial · Dados</div>
          <h1 className="bm-hero__title" style={{ color: 'white' }}>Resultados imediatos.<br/>IA com propósito.</h1>
          <p className="bm-hero__sub">Mais de uma centena de projetos bem-sucedidos para empresas líderes nos EUA e na América Latina.</p>
          <div className="bm-hero__ctas">
            <a className="bm-btn bm-btn--primary" href="#">Iniciar projeto</a>
            <a className="bm-btn bm-btn--ghost-light" href="#">Ver casos ›</a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Solutions() {
  const items = [
    { eye: 'AI Discovery', title: 'Encontre as oportunidades certas.', desc: 'Mapeamos casos de uso de IA com ROI estimado em 4 semanas.', tone: 'light' },
    { eye: 'AI Engineering', title: 'Coloque modelos em produção.', desc: 'Da prova de conceito ao deploy — pipelines, MLOps e observabilidade.', tone: 'brand' },
    { eye: 'Data Platforms', title: 'Dado certo, na hora certa.', desc: 'Plataformas modernas de dados, governança e qualidade end-to-end.', tone: 'deep' },
  ];
  return (
    <section className="bm-section">
      <div className="bm-container">
        <div className="bm-section-head">
          <h2>O que entregamos.</h2>
          <a className="bm-link" href="#">Todas as soluções ›</a>
        </div>
        <div className="bm-card-grid">
          {items.map(it => (
            <div key={it.eye} className={'bm-card ' + (it.tone === 'dark' ? 'bm-card--dark' : it.tone === 'brand' ? 'bm-card--brand' : it.tone === 'deep' ? 'bm-card--deep' : '')}>
              <div className="bm-card__eye">{it.eye}</div>
              <h3 className="bm-card__title">{it.title}</h3>
              <p className="bm-card__desc">{it.desc}</p>
              <a className="bm-card__link" href="#">Saiba mais ›</a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Stats() {
  const stats = [
    { num: '+100', label: 'projetos de IA e dados entregues' },
    { num: '15+', label: 'países nas Américas atendidos' },
    { num: '4 sem.', label: 'do discovery ao primeiro caso de uso' },
    { num: '34%', label: 'média de ganho em conversão pós-modelo' },
  ];
  return (
    <section className="bm-section bm-section--tight">
      <div className="bm-container">
        <div className="bm-stats">
          {stats.map(s => (
            <div key={s.label}>
              <div className="bm-stat__num">{s.num}</div>
              <div className="bm-stat__label">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ShowcaseStage() {
  return (
    <section className="bm-section">
      <div className="bm-container">
        <div className="bm-stage" style={{ background: "url('../../assets/bg-network.jpg') center/cover", color: 'white', minHeight: 480, justifyContent: 'center' }}>
          <div className="bm-stage__eyebrow" style={{ color: 'rgba(255,255,255,0.7)' }}>Case · Fintech LATAM</div>
          <h2 className="bm-stage__title" style={{ color: 'white' }}>+34% em conversão. <br/>Em três meses.</h2>
          <p className="bm-stage__sub" style={{ color: 'rgba(255,255,255,0.85)' }}>Modelo de propensão para 12 milhões de transações mensais — desenhado, treinado e em produção.</p>
          <a className="bm-btn bm-btn--ghost-light" href="#">Ler o caso ›</a>
        </div>
      </div>
    </section>
  );
}

function IndustriesGrid() {
  const ind = [
    { t: 'Financial Services', d: 'Modelos de risco, fraude e propensão para bancos e fintechs.' },
    { t: 'Healthcare', d: 'Dados clínicos, NLP em prontuários e previsão de demanda.' },
    { t: 'Retail & CPG', d: 'Personalização, supply chain e pricing dinâmico.' },
    { t: 'Industria & Energia', d: 'Manutenção preditiva, otimização e visão computacional.' },
  ];
  return (
    <section className="bm-section bm-section--tight" style={{ background: 'var(--neutral-50)' }}>
      <div className="bm-container">
        <div className="bm-section-head">
          <h2>Indústrias que servimos.</h2>
          <a className="bm-link" href="#">Ver todas ›</a>
        </div>
        <div className="bm-card-grid bm-card-grid--2">
          {ind.map(i => (
            <div key={i.t} className="bm-card" style={{ background: 'white', minHeight: 200 }}>
              <h3 className="bm-card__title">{i.t}</h3>
              <p className="bm-card__desc">{i.d}</p>
              <a className="bm-card__link" href="#">Conheça ›</a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="bm-section">
      <div className="bm-container">
        <div className="bm-stage bm-stage--dark" style={{ background: "url('../../assets/bg-liquid-blue.png') center/cover" }}>
          <h2 className="bm-stage__title" style={{ color: 'white' }}>Pronto para começar?</h2>
          <p className="bm-stage__sub" style={{ color: 'rgba(255,255,255,0.85)' }}>Conte sobre o desafio. Voltamos em até um dia útil com um plano inicial.</p>
          <div style={{ display: 'flex', gap: 12 }}>
            <a className="bm-btn bm-btn--primary" href="#">Falar com a bluemetrics</a>
            <a className="bm-btn bm-btn--ghost-light" href="#">Agenda direta ›</a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const cols = [
    { h: 'Soluções', l: ['AI Discovery', 'AI Engineering', 'Data Platforms', 'MLOps'] },
    { h: 'Indústrias', l: ['Financial Services', 'Healthcare', 'Retail & CPG', 'Indústria'] },
    { h: 'Empresa', l: ['Sobre', 'Carreiras', 'Insights', 'Imprensa'] },
    { h: 'Recursos', l: ['Casos', 'Whitepapers', 'Eventos', 'Brand kit'] },
    { h: 'Contato', l: ['São Paulo', 'Miami', 'oi@bluemetrics.com', 'LinkedIn'] },
  ];
  return (
    <footer className="bm-footer">
      <div className="bm-footer__grid">
        {cols.map(c => (
          <div key={c.h} className="bm-footer__col">
            <h4>{c.h}</h4>
            {c.l.map(a => <a key={a} href="#">{a}</a>)}
          </div>
        ))}
      </div>
      <div className="bm-footer__bottom">
        <span>© 2026 bluemetrics. Todos os direitos reservados.</span>
        <span>Privacidade · Termos · Cookies</span>
      </div>
    </footer>
  );
}

Object.assign(window, { NavBar, Hero, Solutions, Stats, ShowcaseStage, IndustriesGrid, CTASection, Footer });
