# bluemetrics-design-system

Design tokens, fonts, brand assets, and component previews for BlueMetrics' 2026 visual identity — Apple-inspired editorial layout + BlueMetrics brand palette. Drop this repo into any BlueMetrics HTML/web project.

## Structure

```
styles.css            Entry point — @imports colors_and_type.css
colors_and_type.css   All design tokens (color, type, spacing, radii, shadow, motion) + base element styles
fonts/                Self-hosted Outfit (display) + Wix Madefor Text (body), all weights, TTF
assets/               Logo lockups (12: horizontal/vertical/symbol × blue/deep-blue/black/white) + brand background imagery
docs/                 Original brand guidelines PDF (source of truth for logo/color/type rules)
preview/              Small HTML specimens — one concept per file (colors, type, buttons, cards, nav, etc.)
ui_kits/website/      Full homepage recreation built on this system, as a real-world usage reference
SKILL.md              Agent-skill manifest (for use with Claude Code / other AI coding agents)
```

## Quick start

```html
<link rel="stylesheet" href="styles.css">
```

Fonts self-host via relative `fonts/` paths already baked into the CSS, so keep `styles.css`/`colors_and_type.css` and `fonts/` at the same relative depth (both at repo root, or both copied together into your project). Everything else (`h1`–`h6`, `p`, `a`, `::selection`, and the `--bm-*` / `--neutral-*` / `--space-*` / `--radius-*` custom properties) is ready to use.

See `preview/` for live examples of each token and component in isolation, and `ui_kits/website/` for a full page built end-to-end with the system.

## Key tokens

- **Primary**: `--bm-blue` `#0c27e8`, `--bm-deep-blue` `#030a8b`. One accent color; support palette (`--bm-mint/cyan/green/yellow/purple/magenta/orange`) is for data viz and status only — never layout fills.
- **Type**: Outfit (display/headings) + Wix Madefor Text (body, 17px default).
- **Radii**: 18px cards, 28px hero tiles, 980px pill buttons.
- **Spacing**: 4/8/12/16/24/32/48/64/96/128px scale.

## Using in a new project

1. Copy `styles.css`, `colors_and_type.css`, `fonts/`, and `assets/` into your project.
2. Link `styles.css` in `<head>`.
3. Reference logos/backgrounds from `assets/` (e.g. `assets/logo-blue-horizontal.png`).
4. Match voice/tone: lowercase "bluemetrics" wordmark, sentence-case headlines, Brazilian Portuguese primary copy.
